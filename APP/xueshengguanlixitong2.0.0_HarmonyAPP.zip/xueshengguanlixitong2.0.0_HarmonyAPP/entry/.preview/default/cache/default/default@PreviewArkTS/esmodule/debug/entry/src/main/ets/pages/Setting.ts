if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Setting_Params {
    oldPwd?: string;
    newPwd?: string;
    confirmPwd?: string;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import { currentUser, updatePassword, setCurrentUser, loadUserData } from "@normalized:N&&&entry/src/main/ets/model/StudentData&";
import type { UserInfo } from "@normalized:N&&&entry/src/main/ets/model/StudentData&";
class Setting extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__oldPwd = new ObservedPropertySimplePU('', this, "oldPwd");
        this.__newPwd = new ObservedPropertySimplePU('', this, "newPwd");
        this.__confirmPwd = new ObservedPropertySimplePU('', this, "confirmPwd");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Setting_Params) {
        if (params.oldPwd !== undefined) {
            this.oldPwd = params.oldPwd;
        }
        if (params.newPwd !== undefined) {
            this.newPwd = params.newPwd;
        }
        if (params.confirmPwd !== undefined) {
            this.confirmPwd = params.confirmPwd;
        }
    }
    updateStateVars(params: Setting_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__oldPwd.purgeDependencyOnElmtId(rmElmtId);
        this.__newPwd.purgeDependencyOnElmtId(rmElmtId);
        this.__confirmPwd.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__oldPwd.aboutToBeDeleted();
        this.__newPwd.aboutToBeDeleted();
        this.__confirmPwd.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __oldPwd: ObservedPropertySimplePU<string>;
    get oldPwd() {
        return this.__oldPwd.get();
    }
    set oldPwd(newValue: string) {
        this.__oldPwd.set(newValue);
    }
    private __newPwd: ObservedPropertySimplePU<string>;
    get newPwd() {
        return this.__newPwd.get();
    }
    set newPwd(newValue: string) {
        this.__newPwd.set(newValue);
    }
    private __confirmPwd: ObservedPropertySimplePU<string>;
    get confirmPwd() {
        return this.__confirmPwd.get();
    }
    set confirmPwd(newValue: string) {
        this.__confirmPwd.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Setting.ets(13:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F5F5F5');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部导航
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Setting.ets(15:7)", "entry");
            // 顶部导航
            Row.width("100%");
            // 顶部导航
            Row.padding(15);
            // 顶部导航
            Row.backgroundColor(Color.White);
            // 顶部导航
            Row.shadow({ radius: 3 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("←");
            Text.debugLine("entry/src/main/ets/pages/Setting.ets(16:9)", "entry");
            Text.fontSize(30);
            Text.onClick(() => router.back());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("设置");
            Text.debugLine("entry/src/main/ets/pages/Setting.ets(19:9)", "entry");
            Text.fontSize(28);
            Text.fontWeight(FontWeight.Bold);
            Text.layoutWeight(1);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        // 顶部导航
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 用户信息
            Stack.create({ alignContent: Alignment.Center });
            Stack.debugLine("entry/src/main/ets/pages/Setting.ets(31:7)", "entry");
            // 用户信息
            Stack.width("100%");
            // 用户信息
            Stack.height(120);
            // 用户信息
            Stack.backgroundColor(Color.White);
            // 用户信息
            Stack.margin({ top: 10 });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/Setting.ets(32:9)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("当前登录用户");
            Text.debugLine("entry/src/main/ets/pages/Setting.ets(33:11)", "entry");
            Text.fontSize(18);
            Text.fontColor(Color.Grey);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(currentUser);
            Text.debugLine("entry/src/main/ets/pages/Setting.ets(36:11)", "entry");
            Text.fontSize(26);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.Blue);
        }, Text);
        Text.pop();
        Column.pop();
        // 用户信息
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 修改密码
            Column.create({ space: 15 });
            Column.debugLine("entry/src/main/ets/pages/Setting.ets(48:7)", "entry");
            // 修改密码
            Column.padding(20);
            // 修改密码
            Column.width('100%');
            // 修改密码
            Column.margin({ top: 20 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "请输入旧密码" });
            TextInput.debugLine("entry/src/main/ets/pages/Setting.ets(49:9)", "entry");
            TextInput.type(InputType.Password);
            TextInput.width('85%');
            TextInput.height(50);
            TextInput.border({ width: 1, radius: 8 });
            TextInput.onChange(v => this.oldPwd = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "请输入新密码" });
            TextInput.debugLine("entry/src/main/ets/pages/Setting.ets(56:9)", "entry");
            TextInput.type(InputType.Password);
            TextInput.width('85%');
            TextInput.height(50);
            TextInput.border({ width: 1, radius: 8 });
            TextInput.onChange(v => this.newPwd = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "确认新密码" });
            TextInput.debugLine("entry/src/main/ets/pages/Setting.ets(63:9)", "entry");
            TextInput.type(InputType.Password);
            TextInput.width('85%');
            TextInput.height(50);
            TextInput.border({ width: 1, radius: 8 });
            TextInput.onChange(v => this.confirmPwd = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("确认修改密码");
            Button.debugLine("entry/src/main/ets/pages/Setting.ets(70:9)", "entry");
            Button.width(200);
            Button.height(50);
            Button.backgroundColor(Color.Blue);
            Button.onClick(() => this.doChangePwd());
        }, Button);
        Button.pop();
        // 修改密码
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 退出登录
            Button.createWithLabel("退出登录");
            Button.debugLine("entry/src/main/ets/pages/Setting.ets(81:7)", "entry");
            // 退出登录
            Button.width(200);
            // 退出登录
            Button.height(50);
            // 退出登录
            Button.backgroundColor(Color.Red);
            // 退出登录
            Button.margin({ top: 30 });
            // 退出登录
            Button.onClick(() => this.logout());
        }, Button);
        // 退出登录
        Button.pop();
        Column.pop();
    }
    // ✅ 显式标注返回类型 + try-catch 捕获异常，消除所有警告
    async doChangePwd(): Promise<void> {
        try {
            if (!this.oldPwd || !this.newPwd || !this.confirmPwd) {
                promptAction.showToast({ message: "请填写完整" });
                return;
            }
            if (this.newPwd !== this.confirmPwd) {
                promptAction.showToast({ message: "两次密码不一致" });
                return;
            }
            if (this.newPwd.length < 6) {
                promptAction.showToast({ message: "密码至少6位" });
                return;
            }
            const userList: UserInfo[] = await loadUserData();
            const user = userList.find(u => u.username === currentUser);
            if (!user || user.password !== this.oldPwd) {
                promptAction.showToast({ message: "旧密码错误" });
                return;
            }
            const success: boolean = await updatePassword(currentUser, this.newPwd);
            if (success) {
                promptAction.showToast({ message: "修改成功，请重新登录" });
                setTimeout(() => this.logout(), 1000);
            }
            else {
                promptAction.showToast({ message: "修改失败" });
            }
        }
        catch (err) {
            console.error("修改密码异常：", JSON.stringify(err));
            promptAction.showToast({ message: "操作异常，请重试" });
        }
    }
    // ✅ 同步函数无需返回类型标注，逻辑不变
    logout(): void {
        setCurrentUser(''); // 强制清空账号
        router.replaceUrl({ url: "pages/Login" }); // 用 replace 彻底销毁页面栈
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Setting";
    }
}
registerNamedRoute(() => new Setting(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/Setting", pageFullPath: "entry/src/main/ets/pages/Setting", integratedHsp: "false", moduleType: "followWithHap" });
