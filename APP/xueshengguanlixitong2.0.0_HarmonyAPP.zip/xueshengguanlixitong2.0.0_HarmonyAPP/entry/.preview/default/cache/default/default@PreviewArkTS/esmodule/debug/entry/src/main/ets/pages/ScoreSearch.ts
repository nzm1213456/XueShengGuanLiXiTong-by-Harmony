if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ScoreSearch_Params {
    searchId?: string;
    searchName?: string;
    searchClass?: string;
    searchScore?: string;
    showList?: ScoreInfo[];
    localList?: ScoreInfo[];
}
import router from "@ohos:router";
import { loadStudentData } from "@normalized:N&&&entry/src/main/ets/model/StudentData&";
import type { ScoreInfo } from "@normalized:N&&&entry/src/main/ets/model/StudentData&";
class ScoreSearch extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__searchId = new ObservedPropertySimplePU('', this, "searchId");
        this.__searchName = new ObservedPropertySimplePU('', this, "searchName");
        this.__searchClass = new ObservedPropertySimplePU('', this, "searchClass");
        this.__searchScore = new ObservedPropertySimplePU('', this, "searchScore");
        this.__showList = new ObservedPropertyObjectPU([], this, "showList");
        this.localList = [];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ScoreSearch_Params) {
        if (params.searchId !== undefined) {
            this.searchId = params.searchId;
        }
        if (params.searchName !== undefined) {
            this.searchName = params.searchName;
        }
        if (params.searchClass !== undefined) {
            this.searchClass = params.searchClass;
        }
        if (params.searchScore !== undefined) {
            this.searchScore = params.searchScore;
        }
        if (params.showList !== undefined) {
            this.showList = params.showList;
        }
        if (params.localList !== undefined) {
            this.localList = params.localList;
        }
    }
    updateStateVars(params: ScoreSearch_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__searchId.purgeDependencyOnElmtId(rmElmtId);
        this.__searchName.purgeDependencyOnElmtId(rmElmtId);
        this.__searchClass.purgeDependencyOnElmtId(rmElmtId);
        this.__searchScore.purgeDependencyOnElmtId(rmElmtId);
        this.__showList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__searchId.aboutToBeDeleted();
        this.__searchName.aboutToBeDeleted();
        this.__searchClass.aboutToBeDeleted();
        this.__searchScore.aboutToBeDeleted();
        this.__showList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 查询条件
    private __searchId: ObservedPropertySimplePU<string>;
    get searchId() {
        return this.__searchId.get();
    }
    set searchId(newValue: string) {
        this.__searchId.set(newValue);
    }
    private __searchName: ObservedPropertySimplePU<string>;
    get searchName() {
        return this.__searchName.get();
    }
    set searchName(newValue: string) {
        this.__searchName.set(newValue);
    }
    private __searchClass: ObservedPropertySimplePU<string>;
    get searchClass() {
        return this.__searchClass.get();
    }
    set searchClass(newValue: string) {
        this.__searchClass.set(newValue);
    }
    private __searchScore: ObservedPropertySimplePU<string>;
    get searchScore() {
        return this.__searchScore.get();
    }
    set searchScore(newValue: string) {
        this.__searchScore.set(newValue);
    }
    // 显示列表：默认空数组 → 打开页面不显示任何数据
    private __showList: ObservedPropertyObjectPU<ScoreInfo[]>;
    get showList() {
        return this.__showList.get();
    }
    set showList(newValue: ScoreInfo[]) {
        this.__showList.set(newValue);
    }
    // 本地变量，用来接收数据，不直接修改导入的 scoreDataList
    private localList: ScoreInfo[];
    // 页面显示时，加载最新永久数据
    async aboutToAppear() {
        this.localList = await loadStudentData();
    }
    // 查询按钮点击才筛选
    doSearch() {
        let result = this.localList.filter(item => {
            // 学号模糊匹配
            const matchId = this.searchId === '' || item.id.toString().includes(this.searchId.trim());
            // 姓名模糊匹配
            const matchName = this.searchName === '' || item.name.includes(this.searchName.trim());
            // 班级模糊匹配
            const matchClass = this.searchClass === '' || item.classes.includes(this.searchClass.trim());
            // 成绩精确匹配
            let matchScore = true;
            if (this.searchScore.trim() !== '') {
                const score = parseInt(this.searchScore);
                if (!isNaN(score)) {
                    matchScore = item.score === score;
                }
            }
            return matchId && matchName && matchClass && matchScore;
        });
        // 只有查询后才赋值
        this.showList = result;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(48:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F5F5F5');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部导航
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(50:7)", "entry");
            // 顶部导航
            Row.width("100%");
            // 顶部导航
            Row.padding(15);
            // 顶部导航
            Row.backgroundColor(Color.White);
            // 顶部导航
            Row.shadow({ radius: 3 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("←");
            Text.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(51:9)", "entry");
            Text.fontSize(30);
            Text.onClick(() => router.back());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("成绩查询");
            Text.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(54:9)", "entry");
            Text.fontSize(28);
            Text.fontWeight(FontWeight.Bold);
            Text.layoutWeight(1);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        // 顶部导航
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 查询输入区域
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(66:7)", "entry");
            // 查询输入区域
            Column.padding(15);
            // 查询输入区域
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "学号" });
            TextInput.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(67:9)", "entry");
            TextInput.width('85%');
            TextInput.height(48);
            TextInput.border({ width: 1, radius: 8 });
            TextInput.type(InputType.Number);
            TextInput.onChange(v => this.searchId = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "姓名" });
            TextInput.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(74:9)", "entry");
            TextInput.width('85%');
            TextInput.height(48);
            TextInput.border({ width: 1, radius: 8 });
            TextInput.onChange(v => this.searchName = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "班级" });
            TextInput.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(80:9)", "entry");
            TextInput.width('85%');
            TextInput.height(48);
            TextInput.border({ width: 1, radius: 8 });
            TextInput.onChange(v => this.searchClass = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "成绩" });
            TextInput.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(86:9)", "entry");
            TextInput.width('85%');
            TextInput.height(48);
            TextInput.border({ width: 1, radius: 8 });
            TextInput.type(InputType.Number);
            TextInput.onChange(v => this.searchScore = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 查询按钮
            Button.createWithLabel("查询");
            Button.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(94:9)", "entry");
            // 查询按钮
            Button.width(180);
            // 查询按钮
            Button.height(50);
            // 查询按钮
            Button.backgroundColor(Color.Blue);
            // 查询按钮
            Button.fontSize(18);
            // 查询按钮
            Button.borderRadius(10);
            // 查询按钮
            Button.onClick(() => this.doSearch());
        }, Button);
        // 查询按钮
        Button.pop();
        // 查询输入区域
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 成绩列表：默认空，查询后才显示
            List.create();
            List.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(106:7)", "entry");
            // 成绩列表：默认空，查询后才显示
            List.divider({ strokeWidth: 5, color: '#99E6C8' });
            // 成绩列表：默认空，查询后才显示
            List.width('100%');
            // 成绩列表：默认空，查询后才显示
            List.height('100%');
            // 成绩列表：默认空，查询后才显示
            List.layoutWeight(1);
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, true);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.height(110);
                        ListItem.backgroundColor('#E8FBF2');
                        ListItem.onClick(() => {
                            router.pushUrl({
                                url: "pages/StudentEdit",
                                params: { studentId: item.id }
                            });
                        });
                        ListItem.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(108:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create({ space: 5 });
                            Column.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(109:13)", "entry");
                            Column.width('100%');
                            Column.height('100%');
                            Column.justifyContent(FlexAlign.Center);
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(`学号：${item.id}`);
                            Text.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(110:15)", "entry");
                            Text.fontSize(18);
                            Text.textAlign(TextAlign.Center);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(`姓名：${item.name}`);
                            Text.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(113:15)", "entry");
                            Text.fontSize(18);
                            Text.textAlign(TextAlign.Center);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(`班级：${item.classes}`);
                            Text.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(116:15)", "entry");
                            Text.fontSize(18);
                            Text.textAlign(TextAlign.Center);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(`成绩：${item.score} 分`);
                            Text.debugLine("entry/src/main/ets/pages/ScoreSearch.ets(119:15)", "entry");
                            Text.fontColor(Color.Blue);
                            Text.fontWeight(FontWeight.Bold);
                            Text.fontSize(18);
                            Text.textAlign(TextAlign.Center);
                        }, Text);
                        Text.pop();
                        Column.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.showList, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        // 成绩列表：默认空，查询后才显示
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ScoreSearch";
    }
}
registerNamedRoute(() => new ScoreSearch(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/ScoreSearch", pageFullPath: "entry/src/main/ets/pages/ScoreSearch", integratedHsp: "false", moduleType: "followWithHap" });
