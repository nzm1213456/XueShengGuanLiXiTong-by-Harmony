if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface StudentList_Params {
    studentList?: ScoreInfo[];
    localList?: ScoreInfo[];
}
import router from "@ohos:router";
import { loadStudentData } from "@normalized:N&&&entry/src/main/ets/model/StudentData&";
import type { ScoreInfo } from "@normalized:N&&&entry/src/main/ets/model/StudentData&";
class StudentList extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__studentList = new ObservedPropertyObjectPU([], this, "studentList");
        this.localList = [];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: StudentList_Params) {
        if (params.studentList !== undefined) {
            this.studentList = params.studentList;
        }
        if (params.localList !== undefined) {
            this.localList = params.localList;
        }
    }
    updateStateVars(params: StudentList_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__studentList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__studentList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 关键：用 State 包裹数据源 → 删改后自动刷新页面
    private __studentList: ObservedPropertyObjectPU<ScoreInfo[]>;
    get studentList() {
        return this.__studentList.get();
    }
    set studentList(newValue: ScoreInfo[]) {
        this.__studentList.set(newValue);
    }
    // 本地变量，接收数据，不直接修改导入的 scoreDataList
    private localList: ScoreInfo[];
    // 页面每次显示时，重新加载最新数据
    async aboutToAppear() {
        await this.refreshList();
    }
    // 刷新学生列表
    async refreshList() {
        // 从永久存储读取数据
        this.localList = await loadStudentData();
        // 赋值给页面渲染用的变量
        this.studentList = [...this.localList];
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/StudentList.ets(27:5)", "entry");
            Column.width("100%");
            Column.height("100%");
            Column.backgroundColor('#F5F5F5');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部导航栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudentList.ets(29:7)", "entry");
            // 顶部导航栏
            Row.width("100%");
            // 顶部导航栏
            Row.padding(15);
            // 顶部导航栏
            Row.backgroundColor(Color.White);
            // 顶部导航栏
            Row.shadow({ radius: 3 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("←");
            Text.debugLine("entry/src/main/ets/pages/StudentList.ets(30:9)", "entry");
            Text.fontSize(30);
            Text.onClick(() => router.back());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("学生列表");
            Text.debugLine("entry/src/main/ets/pages/StudentList.ets(34:9)", "entry");
            Text.fontSize(28);
            Text.fontWeight(FontWeight.Bold);
            Text.layoutWeight(1);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        // 顶部导航栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 学生列表 —— 点击跳转到编辑页
            List.create({ space: 0 });
            List.debugLine("entry/src/main/ets/pages/StudentList.ets(46:7)", "entry");
            // 学生列表 —— 点击跳转到编辑页
            List.divider({ strokeWidth: 5, color: "#FF99BB" });
            // 学生列表 —— 点击跳转到编辑页
            List.width("100%");
            // 学生列表 —— 点击跳转到编辑页
            List.height("100%");
            // 学生列表 —— 点击跳转到编辑页
            List.layoutWeight(1);
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, true);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.height(120);
                        ListItem.backgroundColor("#FFE6EF");
                        ListItem.onClick(() => {
                            router.pushUrl({
                                url: "pages/StudentEdit",
                                params: { studentId: item.id }
                            });
                        });
                        ListItem.debugLine("entry/src/main/ets/pages/StudentList.ets(48:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create({ space: 6 });
                            Column.debugLine("entry/src/main/ets/pages/StudentList.ets(49:13)", "entry");
                            Column.width("100%");
                            Column.height("100%");
                            Column.justifyContent(FlexAlign.Center);
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(`学号：${item.id}`);
                            Text.debugLine("entry/src/main/ets/pages/StudentList.ets(50:15)", "entry");
                            Text.textAlign(TextAlign.Center);
                            Text.fontSize(19);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(`姓名：${item.name}`);
                            Text.debugLine("entry/src/main/ets/pages/StudentList.ets(53:15)", "entry");
                            Text.textAlign(TextAlign.Center);
                            Text.fontSize(19);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(`班级：${item.classes}`);
                            Text.debugLine("entry/src/main/ets/pages/StudentList.ets(56:15)", "entry");
                            Text.textAlign(TextAlign.Center);
                            Text.fontSize(19);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(`成绩：${item.score}`);
                            Text.debugLine("entry/src/main/ets/pages/StudentList.ets(59:15)", "entry");
                            Text.textAlign(TextAlign.Center);
                            Text.fontSize(19);
                        }, Text);
                        Text.pop();
                        Column.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.studentList, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        // 学生列表 —— 点击跳转到编辑页
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "StudentList";
    }
}
registerNamedRoute(() => new StudentList(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/StudentList", pageFullPath: "entry/src/main/ets/pages/StudentList", integratedHsp: "false", moduleType: "followWithHap" });
