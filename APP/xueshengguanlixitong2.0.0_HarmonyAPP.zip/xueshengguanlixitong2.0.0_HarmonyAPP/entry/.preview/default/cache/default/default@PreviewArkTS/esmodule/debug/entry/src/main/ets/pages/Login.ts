if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Login_Params {
    username?: string;
    password?: string;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import { loadUserData, setCurrentUser } from "@normalized:N&&&entry/src/main/ets/model/StudentData&";
import type { UserInfo } from "@normalized:N&&&entry/src/main/ets/model/StudentData&";
class Login extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__username = new ObservedPropertySimplePU('', this, "username");
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Login_Params) {
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
    }
    updateStateVars(params: Login_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__username.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __username: ObservedPropertySimplePU<string>;
    get username() {
        return this.__username.get();
    }
    set username(newValue: string) {
        this.__username.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    async doLogin() {
        try {
            if (!this.username || !this.password) {
                promptAction.showToast({ message: "请输入账号和密码" });
                return;
            }
            const userList: UserInfo[] = await loadUserData();
            // 修复find回调类型报错
            const findUser: UserInfo | undefined = userList.find((u: UserInfo, _index: number, _arr: UserInfo[]) => u.username === this.username);
            if (!findUser) {
                promptAction.showToast({ message: "账号不存在" });
                return;
            }
            if (findUser.password === this.password) {
                setCurrentUser('');
                await new Promise<void>(resolve => setTimeout(resolve, 50));
                setCurrentUser(this.username);
                promptAction.showToast({ message: "登录成功" });
                // 路由异常捕获
                try {
                    router.replaceUrl({ url: "pages/Index" });
                }
                catch {
                    promptAction.showToast({ message: "页面跳转失败" });
                }
            }
            else {
                promptAction.showToast({ message: "密码错误" });
            }
        }
        catch {
            promptAction.showToast({ message: "操作异常，请重试" });
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 25 });
            Column.debugLine("entry/src/main/ets/pages/Login.ets(47:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
            Column.backgroundColor('#F5F5F5');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("用户登录");
            Text.debugLine("entry/src/main/ets/pages/Login.ets(48:7)", "entry");
            Text.fontSize(36);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.Blue);
            Text.margin({ top: 80 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "请输入账号", text: this.username });
            TextInput.debugLine("entry/src/main/ets/pages/Login.ets(54:7)", "entry");
            TextInput.width('85%');
            TextInput.height(55);
            TextInput.border({ width: 1, radius: 10 });
            TextInput.onChange((v: string) => this.username = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "请输入密码", text: this.password });
            TextInput.debugLine("entry/src/main/ets/pages/Login.ets(60:7)", "entry");
            TextInput.type(InputType.Password);
            TextInput.width('85%');
            TextInput.height(55);
            TextInput.border({ width: 1, radius: 10 });
            TextInput.onChange((v: string) => this.password = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("登录");
            Button.debugLine("entry/src/main/ets/pages/Login.ets(67:7)", "entry");
            Button.width(180);
            Button.height(55);
            Button.backgroundColor(Color.Blue);
            Button.fontSize(20);
            Button.borderRadius(12);
            Button.onClick(() => this.doLogin());
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("没有账号？立即注册");
            Text.debugLine("entry/src/main/ets/pages/Login.ets(75:7)", "entry");
            Text.fontSize(17);
            Text.fontColor(Color.Grey);
            Text.onClick(() => {
                try {
                    router.pushUrl({ url: "pages/Register" });
                }
                catch {
                    promptAction.showToast({ message: "跳转失败" });
                }
            });
        }, Text);
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Login";
    }
}
registerNamedRoute(() => new Login(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/Login", pageFullPath: "entry/src/main/ets/pages/Login", integratedHsp: "false", moduleType: "followWithHap" });
