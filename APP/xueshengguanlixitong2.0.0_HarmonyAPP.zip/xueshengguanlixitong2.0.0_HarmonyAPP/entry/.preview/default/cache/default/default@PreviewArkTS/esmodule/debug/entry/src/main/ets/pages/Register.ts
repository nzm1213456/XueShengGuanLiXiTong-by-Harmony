if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Register_Params {
    username?: string;
    password?: string;
    confirmPwd?: string;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import { loadUserData, saveUserData } from "@normalized:N&&&entry/src/main/ets/model/StudentData&";
import type { UserInfo } from "@normalized:N&&&entry/src/main/ets/model/StudentData&";
class Register extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__username = new ObservedPropertySimplePU('', this, "username");
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.__confirmPwd = new ObservedPropertySimplePU('', this, "confirmPwd");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Register_Params) {
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.confirmPwd !== undefined) {
            this.confirmPwd = params.confirmPwd;
        }
    }
    updateStateVars(params: Register_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
        this.__confirmPwd.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__username.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        this.__confirmPwd.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __username: ObservedPropertySimplePU<string>;
    get username() {
        return this.__username.get();
    }
    set username(newValue: string) {
        this.__username.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    private __confirmPwd: ObservedPropertySimplePU<string>;
    get confirmPwd() {
        return this.__confirmPwd.get();
    }
    set confirmPwd(newValue: string) {
        this.__confirmPwd.set(newValue);
    }
    async doRegister() {
        if (!this.username || !this.password || !this.confirmPwd) {
            promptAction.showToast({ message: "请填写完整信息" });
            return;
        }
        if (this.password !== this.confirmPwd) {
            promptAction.showToast({ message: "两次密码不一致" });
            return;
        }
        if (this.username.length < 3) {
            promptAction.showToast({ message: "账号至少3位" });
            return;
        }
        if (this.password.length < 6) {
            promptAction.showToast({ message: "密码至少6位" });
            return;
        }
        const userList = await loadUserData();
        const exists = userList.some(u => u.username === this.username);
        if (exists) {
            promptAction.showToast({ message: "该账号已注册" });
            return;
        }
        // 🔥 只插入新用户，不清空数据库
        const newUser: UserInfo = {
            username: this.username,
            password: this.password
        };
        const success = await saveUserData(newUser);
        if (success) {
            promptAction.showToast({ message: "注册成功！" });
            setTimeout(() => router.back(), 100);
        }
        else {
            promptAction.showToast({ message: "注册失败" });
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 22 });
            Column.debugLine("entry/src/main/ets/pages/Register.ets(56:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
            Column.backgroundColor('#F5F5F5');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("用户注册");
            Text.debugLine("entry/src/main/ets/pages/Register.ets(57:7)", "entry");
            Text.fontSize(36);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.Blue);
            Text.margin({ top: 70 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "设置账号（≥3位）", text: this.username });
            TextInput.debugLine("entry/src/main/ets/pages/Register.ets(63:7)", "entry");
            TextInput.width('85%');
            TextInput.height(52);
            TextInput.border({ width: 1, radius: 10 });
            TextInput.onChange(v => this.username = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "设置密码（≥6位）", text: this.password });
            TextInput.debugLine("entry/src/main/ets/pages/Register.ets(69:7)", "entry");
            TextInput.type(InputType.Password);
            TextInput.width('85%');
            TextInput.height(52);
            TextInput.border({ width: 1, radius: 10 });
            TextInput.onChange(v => this.password = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "确认密码", text: this.confirmPwd });
            TextInput.debugLine("entry/src/main/ets/pages/Register.ets(76:7)", "entry");
            TextInput.type(InputType.Password);
            TextInput.width('85%');
            TextInput.height(52);
            TextInput.border({ width: 1, radius: 10 });
            TextInput.onChange(v => this.confirmPwd = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("注册");
            Button.debugLine("entry/src/main/ets/pages/Register.ets(83:7)", "entry");
            Button.width(180);
            Button.height(52);
            Button.backgroundColor(Color.Green);
            Button.fontSize(20);
            Button.borderRadius(12);
            Button.onClick(() => this.doRegister());
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("已有账号？返回登录");
            Text.debugLine("entry/src/main/ets/pages/Register.ets(91:7)", "entry");
            Text.fontSize(17);
            Text.fontColor(Color.Grey);
            Text.onClick(() => router.back());
        }, Text);
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Register";
    }
}
registerNamedRoute(() => new Register(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/Register", pageFullPath: "entry/src/main/ets/pages/Register", integratedHsp: "false", moduleType: "followWithHap" });
