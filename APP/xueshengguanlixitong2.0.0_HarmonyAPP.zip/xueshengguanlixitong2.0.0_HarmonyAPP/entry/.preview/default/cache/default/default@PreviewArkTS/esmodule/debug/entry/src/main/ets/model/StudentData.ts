import relationalStore from "@ohos:data.relationalStore";
import type common from "@ohos:app.ability.common";
export interface ScoreInfo {
    id: number;
    name: string;
    classes: string;
    score: number;
    username: string;
}
export interface UserInfo {
    username: string;
    password: string;
}
const DB_NAME = 'student_score.db';
const TABLE_STUDENT = 'student_score';
const TABLE_USER = 'user_info';
let rdbStore: relationalStore.RdbStore | null = null;
export let currentUser: string = '';
export function setCurrentUser(username: string): void {
    currentUser = username;
}
export async function initStorage(context: common.UIAbilityContext): Promise<void> {
    if (rdbStore)
        return;
    const config: relationalStore.StoreConfig = {
        name: DB_NAME,
        securityLevel: relationalStore.SecurityLevel.S1
    };
    try {
        rdbStore = await relationalStore.getRdbStore(context, config);
        await createTables();
    }
    catch (err) {
        console.error('数据库初始化失败：', err);
    }
}
async function createTables(): Promise<void> {
    if (!rdbStore)
        return;
    try {
        await rdbStore.executeSql(`
    CREATE TABLE IF NOT EXISTS ${TABLE_STUDENT} (
      id INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      classes TEXT NOT NULL,
      score INTEGER NOT NULL,
      username TEXT NOT NULL
    )
  `);
        await rdbStore.executeSql(`
    CREATE TABLE IF NOT EXISTS ${TABLE_USER} (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL
    )
  `);
    }
    catch (err) {
        console.error("建表失败", err);
    }
}
export async function loadStudentData(): Promise<ScoreInfo[]> {
    if (!rdbStore || !currentUser)
        return [];
    try {
        const predicates = new relationalStore.RdbPredicates(TABLE_STUDENT);
        predicates.equalTo('username', currentUser);
        const resultSet = await rdbStore.query(predicates, ['id', 'name', 'classes', 'score', 'username']);
        const list: ScoreInfo[] = [];
        while (resultSet.goToNextRow()) {
            list.push({
                id: resultSet.getLong(0),
                name: resultSet.getString(1),
                classes: resultSet.getString(2),
                score: resultSet.getLong(3),
                username: resultSet.getString(4)
            });
        }
        resultSet.close();
        return list;
    }
    catch (err) {
        console.error("加载学生数据失败", err);
        return [];
    }
}
export async function saveStudentData(list: ScoreInfo[]): Promise<void> {
    if (!rdbStore || !currentUser)
        return;
    try {
        const delPre = new relationalStore.RdbPredicates(TABLE_STUDENT);
        delPre.equalTo('username', currentUser);
        await rdbStore.delete(delPre);
        for (const item of list) {
            await rdbStore.insert(TABLE_STUDENT, {
                id: item.id,
                name: item.name,
                classes: item.classes,
                score: item.score,
                username: currentUser
            });
        }
    }
    catch (err) {
        console.error("保存学生数据失败", err);
    }
}
export async function loadUserData(): Promise<UserInfo[]> {
    if (!rdbStore)
        return [];
    try {
        const predicates = new relationalStore.RdbPredicates(TABLE_USER);
        const resultSet = await rdbStore.query(predicates, ['username', 'password']);
        const list: UserInfo[] = [];
        while (resultSet.goToNextRow()) {
            list.push({
                username: resultSet.getString(0),
                password: resultSet.getString(1)
            });
        }
        resultSet.close();
        return list;
    }
    catch (err) {
        console.error("加载用户数据失败", err);
        return [];
    }
}
// ====================== 🔥 修复：ID 不再变化 ======================
export async function saveUserData(user: UserInfo): Promise<boolean> {
    if (!rdbStore)
        return false;
    try {
        // 只插入新用户，不清空表！ID 永久自增
        await rdbStore.insert(TABLE_USER, {
            username: user.username,
            password: user.password
        });
        return true;
    }
    catch (err) {
        console.error("注册失败（账号可能已存在）", err);
        return false;
    }
}
// =================================================================
export async function updatePassword(username: string, newPwd: string): Promise<boolean> {
    if (!rdbStore)
        return false;
    try {
        const predicates = new relationalStore.RdbPredicates(TABLE_USER);
        predicates.equalTo('username', username);
        const bucket: relationalStore.ValuesBucket = { password: newPwd };
        const count = await rdbStore.update(bucket, predicates);
        return count > 0;
    }
    catch (err) {
        console.error("修改密码失败", err);
        return false;
    }
}
export let scoreDataList: ScoreInfo[] = [];
