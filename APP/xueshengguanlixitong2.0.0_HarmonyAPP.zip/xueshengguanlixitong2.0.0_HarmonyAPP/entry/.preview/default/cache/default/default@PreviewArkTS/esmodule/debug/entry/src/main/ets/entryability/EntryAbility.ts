import UIAbility from "@ohos:app.ability.UIAbility";
import hilog from "@ohos:hilog";
import type window from "@ohos:window";
import type AbilityConstant from "@ohos:app.ability.AbilityConstant";
import type Want from "@ohos:app.ability.Want";
import { initStorage } from "@normalized:N&&&entry/src/main/ets/model/StudentData&";
export default class EntryAbility extends UIAbility {
    async onCreate(want: Want, launchParam: AbilityConstant.LaunchParam): Promise<void> {
        hilog.info(0x0000, 'StudentScore', '%{public}s', 'Ability onCreate');
        // 初始化数据库
        await initStorage(this.context);
    }
    onDestroy(): void {
        hilog.info(0x0000, 'StudentScore', '%{public}s', 'Ability onDestroy');
    }
    onWindowStageCreate(windowStage: window.WindowStage): void {
        hilog.info(0x0000, 'StudentScore', '%{public}s', 'Ability onWindowStageCreate');
        // 加载登录页面
        windowStage.loadContent('pages/Login', (err) => {
            if (err.code) {
                hilog.error(0x0000, 'StudentScore', 'Failed to load content. Cause: %{public}s', JSON.stringify(err) ?? '');
                return;
            }
            hilog.info(0x0000, 'StudentScore', 'Succeeded in loading content.');
        });
    }
    onWindowStageDestroy(): void {
        hilog.info(0x0000, 'StudentScore', '%{public}s', 'Ability onWindowStageDestroy');
    }
    onForeground(): void {
        hilog.info(0x0000, 'StudentScore', '%{public}s', 'Ability onForeground');
    }
    onBackground(): void {
        hilog.info(0x0000, 'StudentScore', '%{public}s', 'Ability onBackground');
    }
}
