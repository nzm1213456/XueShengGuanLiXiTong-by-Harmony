if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ScoreInput_Params {
    stuId?: string;
    stuName?: string;
    stuClass?: string;
    stuScore?: string;
    localList?: ScoreInfo[];
}
import router from "@ohos:router";
import { loadStudentData, saveStudentData, currentUser } from "@normalized:N&&&entry/src/main/ets/model/StudentData&";
import type { ScoreInfo } from "@normalized:N&&&entry/src/main/ets/model/StudentData&";
import promptAction from "@ohos:promptAction";
class ScoreInput extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__stuId = new ObservedPropertySimplePU('', this, "stuId");
        this.__stuName = new ObservedPropertySimplePU('', this, "stuName");
        this.__stuClass = new ObservedPropertySimplePU('', this, "stuClass");
        this.__stuScore = new ObservedPropertySimplePU('', this, "stuScore");
        this.localList = [];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ScoreInput_Params) {
        if (params.stuId !== undefined) {
            this.stuId = params.stuId;
        }
        if (params.stuName !== undefined) {
            this.stuName = params.stuName;
        }
        if (params.stuClass !== undefined) {
            this.stuClass = params.stuClass;
        }
        if (params.stuScore !== undefined) {
            this.stuScore = params.stuScore;
        }
        if (params.localList !== undefined) {
            this.localList = params.localList;
        }
    }
    updateStateVars(params: ScoreInput_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__stuId.purgeDependencyOnElmtId(rmElmtId);
        this.__stuName.purgeDependencyOnElmtId(rmElmtId);
        this.__stuClass.purgeDependencyOnElmtId(rmElmtId);
        this.__stuScore.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__stuId.aboutToBeDeleted();
        this.__stuName.aboutToBeDeleted();
        this.__stuClass.aboutToBeDeleted();
        this.__stuScore.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __stuId: ObservedPropertySimplePU<string>;
    get stuId() {
        return this.__stuId.get();
    }
    set stuId(newValue: string) {
        this.__stuId.set(newValue);
    }
    private __stuName: ObservedPropertySimplePU<string>;
    get stuName() {
        return this.__stuName.get();
    }
    set stuName(newValue: string) {
        this.__stuName.set(newValue);
    }
    private __stuClass: ObservedPropertySimplePU<string>;
    get stuClass() {
        return this.__stuClass.get();
    }
    set stuClass(newValue: string) {
        this.__stuClass.set(newValue);
    }
    private __stuScore: ObservedPropertySimplePU<string>;
    get stuScore() {
        return this.__stuScore.get();
    }
    set stuScore(newValue: string) {
        this.__stuScore.set(newValue);
    }
    private localList: ScoreInfo[];
    async aboutToAppear(): Promise<void> {
        try {
            this.localList = await loadStudentData();
            console.log('✅ 成绩录入页加载数据：', this.localList.length);
        }
        catch (err) {
            console.error("❌ 加载数据失败", err);
        }
    }
    async save(): Promise<void> {
        try {
            if (!currentUser) {
                promptAction.showToast({ message: "请先登录" });
                return;
            }
            if (!this.stuId || !this.stuName || !this.stuClass || !this.stuScore) {
                promptAction.showToast({ message: "请填写完整信息", duration: 2000 });
                return;
            }
            const id: number = parseInt(this.stuId);
            if (isNaN(id) || id <= 0) {
                promptAction.showToast({ message: "学号必须是正整数", duration: 2000 });
                return;
            }
            // ==============================================
            // 🔥 修复：每次保存前 重新加载最新数据！
            // ==============================================
            this.localList = await loadStudentData();
            const exists: boolean = this.localList.some(item => item.id === id);
            if (exists) {
                promptAction.showToast({ message: "该学号已存在！", duration: 2000 });
                return;
            }
            const score: number = parseInt(this.stuScore);
            if (isNaN(score) || score < 0 || score > 100) {
                promptAction.showToast({ message: "成绩必须是0-100的数字", duration: 2000 });
                return;
            }
            this.localList.push({
                id: id,
                name: this.stuName,
                classes: this.stuClass,
                score: score,
                username: currentUser
            });
            await saveStudentData(this.localList);
            promptAction.showToast({ message: "保存成功！", duration: 2000 });
            this.stuId = '';
            this.stuName = '';
            this.stuClass = '';
            this.stuScore = '';
        }
        catch (err) {
            console.error("❌ 保存失败", err);
            promptAction.showToast({ message: "保存失败", duration: 2000 });
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ScoreInput.ets(81:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F5F5F5');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ScoreInput.ets(82:7)", "entry");
            Row.width('100%');
            Row.padding(15);
            Row.backgroundColor(Color.White);
            Row.shadow({ radius: 3 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("←");
            Text.debugLine("entry/src/main/ets/pages/ScoreInput.ets(83:9)", "entry");
            Text.fontSize(30);
            Text.onClick(() => router.back());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("成绩录入");
            Text.debugLine("entry/src/main/ets/pages/ScoreInput.ets(86:9)", "entry");
            Text.fontSize(28);
            Text.fontWeight(FontWeight.Bold);
            Text.layoutWeight(1);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/ScoreInput.ets(97:7)", "entry");
            Column.layoutWeight(1);
            Column.justifyContent(FlexAlign.Center);
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "学号", text: this.stuId });
            TextInput.debugLine("entry/src/main/ets/pages/ScoreInput.ets(98:9)", "entry");
            TextInput.width('85%');
            TextInput.height(52);
            TextInput.type(InputType.Number);
            TextInput.border({ width: 1, radius: 8 });
            TextInput.onChange((v: string) => this.stuId = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "姓名", text: this.stuName });
            TextInput.debugLine("entry/src/main/ets/pages/ScoreInput.ets(105:9)", "entry");
            TextInput.width('85%');
            TextInput.height(52);
            TextInput.border({ width: 1, radius: 8 });
            TextInput.onChange((v: string) => this.stuName = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "班级", text: this.stuClass });
            TextInput.debugLine("entry/src/main/ets/pages/ScoreInput.ets(111:9)", "entry");
            TextInput.width('85%');
            TextInput.height(52);
            TextInput.border({ width: 1, radius: 8 });
            TextInput.onChange((v: string) => this.stuClass = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "成绩", text: this.stuScore });
            TextInput.debugLine("entry/src/main/ets/pages/ScoreInput.ets(117:9)", "entry");
            TextInput.width('85%');
            TextInput.height(52);
            TextInput.type(InputType.Number);
            TextInput.border({ width: 1, radius: 8 });
            TextInput.onChange((v: string) => this.stuScore = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("保存");
            Button.debugLine("entry/src/main/ets/pages/ScoreInput.ets(124:9)", "entry");
            Button.width(180);
            Button.height(52);
            Button.backgroundColor(Color.Blue);
            Button.fontSize(18);
            Button.borderRadius(10);
            Button.onClick(() => this.save());
        }, Button);
        Button.pop();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ScoreInput";
    }
}
registerNamedRoute(() => new ScoreInput(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/ScoreInput", pageFullPath: "entry/src/main/ets/pages/ScoreInput", integratedHsp: "false", moduleType: "followWithHap" });
