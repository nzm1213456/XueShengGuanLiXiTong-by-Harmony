if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface StudentScoreSystem_Params {
}
import router from "@ohos:router";
class StudentScoreSystem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: StudentScoreSystem_Params) {
    }
    updateStateVars(params: StudentScoreSystem_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    menuBtn(txt: string, pageUrl: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(txt);
            Button.debugLine("entry/src/main/ets/pages/Index.ets(8:5)", "entry");
            Button.width(180);
            Button.height(60);
            Button.backgroundColor(Color.Blue);
            Button.fontColor(Color.White);
            Button.fontSize(20);
            Button.borderRadius(30);
            Button.onClick(() => {
                router.pushUrl({ url: pageUrl });
            });
        }, Button);
        Button.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(21:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
            Column.backgroundColor('#F5F5F5');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.Center });
            Stack.debugLine("entry/src/main/ets/pages/Index.ets(22:7)", "entry");
            Stack.width("90%");
            Stack.height(100);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("学生成绩管理系统");
            Text.debugLine("entry/src/main/ets/pages/Index.ets(23:9)", "entry");
            Text.fontSize(35);
            Text.fontColor(Color.Blue);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.Center });
            Stack.debugLine("entry/src/main/ets/pages/Index.ets(31:7)", "entry");
            Stack.width(280);
            Stack.height(350);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 30 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(32:9)", "entry");
        }, Column);
        this.menuBtn.bind(this)("学生列表", "pages/StudentList");
        this.menuBtn.bind(this)("成绩录入", "pages/ScoreInput");
        this.menuBtn.bind(this)("成绩查询", "pages/ScoreSearch");
        this.menuBtn.bind(this)("设置", "pages/Setting");
        Column.pop();
        Stack.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "StudentScoreSystem";
    }
}
registerNamedRoute(() => new StudentScoreSystem(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
