if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface StudentEdit_Params {
    studentParams?: StudentParams;
    oldId?: number;
    stuId?: number;
    name?: string;
    classes?: string;
    score?: number;
    localList?: ScoreInfo[];
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import { loadStudentData, saveStudentData, currentUser } from "@normalized:N&&&entry/src/main/ets/model/StudentData&";
import type { ScoreInfo } from "@normalized:N&&&entry/src/main/ets/model/StudentData&";
interface StudentParams {
    studentId: number;
}
class StudentEdit extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.studentParams = router.getParams() as StudentParams;
        this.oldId = this.studentParams.studentId;
        this.__stuId = new ObservedPropertySimplePU(0, this, "stuId");
        this.__name = new ObservedPropertySimplePU('', this, "name");
        this.__classes = new ObservedPropertySimplePU('', this, "classes");
        this.__score = new ObservedPropertySimplePU(0, this, "score");
        this.localList = [];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: StudentEdit_Params) {
        if (params.studentParams !== undefined) {
            this.studentParams = params.studentParams;
        }
        if (params.oldId !== undefined) {
            this.oldId = params.oldId;
        }
        if (params.stuId !== undefined) {
            this.stuId = params.stuId;
        }
        if (params.name !== undefined) {
            this.name = params.name;
        }
        if (params.classes !== undefined) {
            this.classes = params.classes;
        }
        if (params.score !== undefined) {
            this.score = params.score;
        }
        if (params.localList !== undefined) {
            this.localList = params.localList;
        }
    }
    updateStateVars(params: StudentEdit_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__stuId.purgeDependencyOnElmtId(rmElmtId);
        this.__name.purgeDependencyOnElmtId(rmElmtId);
        this.__classes.purgeDependencyOnElmtId(rmElmtId);
        this.__score.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__stuId.aboutToBeDeleted();
        this.__name.aboutToBeDeleted();
        this.__classes.aboutToBeDeleted();
        this.__score.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private studentParams: StudentParams;
    private oldId: number;
    private __stuId: ObservedPropertySimplePU<number>;
    get stuId() {
        return this.__stuId.get();
    }
    set stuId(newValue: number) {
        this.__stuId.set(newValue);
    }
    private __name: ObservedPropertySimplePU<string>;
    get name() {
        return this.__name.get();
    }
    set name(newValue: string) {
        this.__name.set(newValue);
    }
    private __classes: ObservedPropertySimplePU<string>;
    get classes() {
        return this.__classes.get();
    }
    set classes(newValue: string) {
        this.__classes.set(newValue);
    }
    private __score: ObservedPropertySimplePU<number>;
    get score() {
        return this.__score.get();
    }
    set score(newValue: number) {
        this.__score.set(newValue);
    }
    private localList: ScoreInfo[];
    async aboutToAppear() {
        await this.loadStudentInfo();
    }
    async loadStudentInfo() {
        try {
            this.localList = await loadStudentData();
            let student = this.localList.find(item => item.id === this.oldId);
            if (student) {
                this.stuId = student.id;
                this.name = student.name;
                this.classes = student.classes;
                this.score = student.score;
            }
        }
        catch (e) {
            console.error("加载学生信息失败", JSON.stringify(e));
        }
    }
    async saveUpdate() {
        try {
            if (!this.name || !this.classes || isNaN(this.score) || isNaN(this.stuId)) {
                promptAction.showToast({ message: "请填写完整信息" });
                return;
            }
            if (this.score < 0 || this.score > 100) {
                promptAction.showToast({ message: "成绩必须在0-100之间" });
                return;
            }
            if (this.stuId <= 0) {
                promptAction.showToast({ message: "学号必须是正整数" });
                return;
            }
            let exists = this.localList.some(item => item.id === this.stuId && item.id !== this.oldId);
            if (exists) {
                promptAction.showToast({ message: "该学号已存在！" });
                return;
            }
            let index = this.localList.findIndex(item => item.id === this.oldId);
            if (index !== -1) {
                // ✅ 修复：添加 username 字段
                this.localList[index] = {
                    id: this.stuId,
                    name: this.name,
                    classes: this.classes,
                    score: this.score,
                    username: currentUser
                };
                await saveStudentData(this.localList);
                promptAction.showToast({ message: "修改成功！" });
                setTimeout(() => router.back(), 100);
            }
        }
        catch (e) {
            console.error("保存失败", JSON.stringify(e));
        }
    }
    async deleteStudent() {
        try {
            let index = this.localList.findIndex(item => item.id === this.oldId);
            if (index !== -1) {
                this.localList.splice(index, 1);
                await saveStudentData(this.localList);
                promptAction.showToast({ message: "删除成功！" });
                setTimeout(() => router.back(), 100);
            }
        }
        catch (e) {
            console.error("删除失败", JSON.stringify(e));
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/StudentEdit.ets(97:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F5F5F5');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/StudentEdit.ets(98:7)", "entry");
            Row.width('100%');
            Row.padding(15);
            Row.backgroundColor(Color.White);
            Row.shadow({ radius: 3 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("←");
            Text.debugLine("entry/src/main/ets/pages/StudentEdit.ets(99:9)", "entry");
            Text.fontSize(30);
            Text.onClick(() => router.back());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("编辑学生信息");
            Text.debugLine("entry/src/main/ets/pages/StudentEdit.ets(102:9)", "entry");
            Text.fontSize(28);
            Text.fontWeight(FontWeight.Bold);
            Text.layoutWeight(1);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/StudentEdit.ets(113:7)", "entry");
            Column.layoutWeight(1);
            Column.justifyContent(FlexAlign.Center);
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "学号", text: this.stuId.toString() });
            TextInput.debugLine("entry/src/main/ets/pages/StudentEdit.ets(114:9)", "entry");
            TextInput.width('85%');
            TextInput.height(52);
            TextInput.type(InputType.Number);
            TextInput.border({ width: 1, radius: 8 });
            TextInput.onChange(v => this.stuId = parseInt(v) || 0);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "姓名", text: this.name });
            TextInput.debugLine("entry/src/main/ets/pages/StudentEdit.ets(121:9)", "entry");
            TextInput.width('85%');
            TextInput.height(52);
            TextInput.border({ width: 1, radius: 8 });
            TextInput.onChange(v => this.name = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "班级", text: this.classes });
            TextInput.debugLine("entry/src/main/ets/pages/StudentEdit.ets(127:9)", "entry");
            TextInput.width('85%');
            TextInput.height(52);
            TextInput.border({ width: 1, radius: 8 });
            TextInput.onChange(v => this.classes = v);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: "成绩", text: this.score.toString() });
            TextInput.debugLine("entry/src/main/ets/pages/StudentEdit.ets(133:9)", "entry");
            TextInput.width('85%');
            TextInput.height(52);
            TextInput.type(InputType.Number);
            TextInput.border({ width: 1, radius: 8 });
            TextInput.onChange(v => this.score = parseInt(v) || 0);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 20 });
            Row.debugLine("entry/src/main/ets/pages/StudentEdit.ets(140:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("确认修改");
            Button.debugLine("entry/src/main/ets/pages/StudentEdit.ets(141:11)", "entry");
            Button.width(150);
            Button.height(50);
            Button.backgroundColor(Color.Blue);
            Button.onClick(() => this.saveUpdate());
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("删除学生");
            Button.debugLine("entry/src/main/ets/pages/StudentEdit.ets(146:11)", "entry");
            Button.width(150);
            Button.height(50);
            Button.backgroundColor(Color.Red);
            Button.onClick(() => this.deleteStudent());
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "StudentEdit";
    }
}
registerNamedRoute(() => new StudentEdit(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/StudentEdit", pageFullPath: "entry/src/main/ets/pages/StudentEdit", integratedHsp: "false", moduleType: "followWithHap" });
